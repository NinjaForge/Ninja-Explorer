<?php
/**
 * @version 	$Id: abstract.php 1528 2010-01-26 23:14:08Z johan $
 * @category	Koowa
 * @package		Koowa_Database
 * @subpackage 	Behavior
 * @copyright	Copyright (C) 2007 - 2010 Johan Janssens. All rights reserved.
 * @license		GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 */

/**
 * Database Creatable Behavior
 *
 * @author		Johan Janssens <johan@nooku.org>
 * @category	Koowa
 * @package     Koowa_Database
 * @subpackage 	Behavior
 */
class KDatabaseBehaviorCreatable extends KDatabaseBehaviorAbstract
{
	/**
	 * Get the methods that are available for mixin based
	 * 
	 * This function conditionaly mixes the behavior. Only if the mixer 
	 * has a 'created_by' or 'created_on' property the behavior will be 
	 * mixed in.
	 * 
	 * @param object The mixer requesting the mixable methods. 
	 * @return array An array of methods
	 */
	public function getMixableMethods(KObject $mixer = null)
	{
		$methods = array();
		
		if(isset($mixer->created_by) || isset($mixer->created_on))  {
			$methods = parent::getMixableMethods($mixer);
		}
	
		return $methods;
	}
	
	/**
	 * Set created information
	 * 	
	 * Requires an 'created_on' and 'created_by' column
	 * 
	 * @return void
	 */
	protected function _beforeTableInsert(KCommandContext $context)
	{
		$row = $context->data; //get the row data being inserted
		
		if(isset($row->created_by) && empty($row->created_by)) {
			$row->created_by  = (int) KFactory::get('lib.koowa.user')->get('id');
		}
		
		if(isset($row->created_on) && (empty($row->created_on) || $row->created_on == $context->caller->getDefault('created_on'))) { 
			$row->created_on  = gmdate('Y-m-d H:i:s');
		}
	}
}