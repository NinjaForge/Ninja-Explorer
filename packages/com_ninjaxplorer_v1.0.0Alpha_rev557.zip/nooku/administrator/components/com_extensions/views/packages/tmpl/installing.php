<? /* $Id: installing.php 16 2010-10-25 18:59:37Z stiandidriksen $ */ ?>
<? defined( 'KOOWA' ) or die( 'Restricted access' ) ?>
<h2 class="working">
	<?= sprintf(@text('Installing %s'), $package) ?>
	<? $b = $total + $i - 1; ?><span><?= sprintf(@text('Package %d of %d'), $i, $b) ?></span>
</h2>