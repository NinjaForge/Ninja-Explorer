<?php
/**
 * @version		$Id: html.php 28 2010-11-05 12:54:01Z stiandidriksen $
 * @category	Nooku
 * @package     Nooku_Components
 * @subpackage  Extensions
 * @copyright	Copyright (C) 2010 Timble CVBA and Contributors. (http://www.timble.net)
 * @license		GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link		http://www.nooku.org
 */

/**
 * @author		Stian Didriksen <stian@ninjaforge.com>
 * @category	Nooku
 * @package     Nooku_Components
 * @subpackage  Extensions
 */
class ComExtensionsViewHtml extends ComDefaultViewHtml
{	
	//Don't do anything here
}