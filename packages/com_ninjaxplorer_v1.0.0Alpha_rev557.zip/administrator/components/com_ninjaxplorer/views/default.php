<?php
/**
 * @version		$Id: default.php 559 2011-03-06 16:57:08Z richie $
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_View
 * @copyright	Copyright (C) 2007 - 2011 NinjaForge. All rights reserved.
 * @license 	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link     	http://ninjaforge.com
 */
defined('KOOWA') or die("Koowa isn't available, or file is accessed directly"); 

/**
 * Default View Class
 *
 * @author		Richie Mortimer <richie@ninjaforge.com>
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_View
 */
class ComNinjaxplorerViewDefault extends ComNinjaViewDefault
{
	/**
	 * Constructor
	 *
	 * @param 	object 	An optional KConfig object with configuration options
	 */
	public function __construct(KConfig $config)
	{
	    parent::__construct($config);
		   
		$model = $this->getModel();
	    if(KInflector::isPlural($this->getName()) && $model->getTotal() < 1) 
	    	$this->_createToolbar()->reset()->append(KFactory::get('admin::com.ninja.toolbar.button.new'));
	}
	
	/**
	 * Return the views output
	 * 
	 * This function will also set up the toolbar, depending on the view. 
	 *
	 * @return string 	The output of the view
	 */
	public function display()
	{
		//Load the js message box plugin
		KFactory::get('admin::com.ninja.helper.default')->js('/Roar.js');
		KFactory::get('admin::com.ninja.helper.default')->css('/Roar.css');
		
		// Display the toolbar
		$toolbar = $this->_createToolbar();
		$path = $this->getModel()->getIdentifier()->path;

		if(KInflector::isPlural($this->getModel()->getIdentifier()->name) && $this->getName() != 'dashboard')
		{
			$this->_mixinMenubar();
		}

		if ($this->getName() == 'dashboard')
		{
			$toolbar->reset();
			$this->_document->setBuffer(false, 'modules', 'submenu');
		}
		else
		{
			$toolbar->append('spacer');
		}

		$toolbar->append(KFactory::get('admin::com.ninja.toolbar.button.about'));

		return parent::display();
	}
}