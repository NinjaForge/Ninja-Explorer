<? /** $Id: default_items.php 480 2010-12-27 12:33:45Z richie $ */ ?>
<? defined( 'KOOWA' ) or die( 'Restricted access' ) ?>

<? foreach ($files as $i => $file) : ?>
<tr class="<?= @ninja('grid.zebra') ?>">
	<td class="grid-check"><?= @ninja('grid.id', array('value' => $file->path)) ?></td>
	<td width="40%">
		<img class="xplorer-mime" src="<?= @$img('/24/'.$file->mime.'.png') ?>" alt="<?= $file->mime ?>" />
		<a href="<?= @route('&path='.$file->path) ?>"><?= $file->name ?></a>
	</td>
	<td width="40%">
		<?= $file->size ?>
	</td>
</tr>
<? endforeach ?>
<?= @ninja('grid.placeholders', array('total' => $total, 'colspan' => 7)) ?>