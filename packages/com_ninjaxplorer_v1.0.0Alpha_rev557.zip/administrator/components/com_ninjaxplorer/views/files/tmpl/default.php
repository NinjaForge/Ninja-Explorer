<? /** $Id: default.php 574 2011-03-13 09:36:08Z richie $ */ ?>
<? defined( 'KOOWA' ) or die( 'Restricted access' ) ?>

<? if($length > 0) : ?>
	<?= @template('admin::com.ninja.view.search.filter_thead') ?>
<? endif ?>

<form action="<?= @route() ?>" method="post" id="<?= @id() ?>" class="placeholder-up-two-lines">
	<table class="adminlist ninja-list">
		<thead>
			<tr>
				<th class="grid-check"><?= @ninja('grid.checkall') ?></th>
				<th><?= @ninja('grid.sort', array('title' => 'Title')) ?></th>
				<th><?= @ninja('grid.sort', array('title' => 'Size')) ?></th>		
			</tr>
		</thead>
		<tbody>
			<?= @template('default_items') ?>
		</tbody>
	</table>
</form>