<?php
/**
 * @version		$Id: ninjaxplorer.php 559 2011-03-06 16:57:08Z richie $
 * @category	Ninjaxplorer
 * @copyright	Copyright (C) 2007 - 2011 NinjaForge. All rights reserved.
 * @license 	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link     	http://ninjaforge.com
 */
defined('KOOWA') or die("Koowa isn't available, or file is accessed directly"); 

//@TODO add proper error handling when com_ninja don't exist
$ninja = JPATH_ADMINISTRATOR.'/components/com_ninja/ninja.php';
if(file_exists($ninja)) require_once $ninja;
else					return;

/** 
* If koowa is unavailable
* Abort the dispatcher
*/
if( !defined('KOOWA') ) return;

KFactory::map('admin::com.ninjaxplorer.template.helper.default', 'admin::com.ninja.helper.default');

// Create the component dispatcher
echo KFactory::get('admin::com.ninjaxplorer.dispatcher')->dispatch(KRequest::get('get.view', 'cmd', 'dashboard'));

// Add untranslated words to the current NB language file
KFactory::get('admin::com.ninja.helper.language');