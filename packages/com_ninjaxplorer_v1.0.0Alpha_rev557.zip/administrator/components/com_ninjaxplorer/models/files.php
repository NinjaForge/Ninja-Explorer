<?php
/**
 * @version		$Id: files.php 574 2011-03-13 09:36:08Z richie $
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_Model
 * @copyright	Copyright (C) 2007 - 2011 NinjaForge. All rights reserved.
 * @license 	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link     	http://ninjaforge.com
 */
defined('KOOWA') or die("Koowa isn't available, or file is accessed directly"); 

/**
 * Files View Model
 *
 * @author		Richie Mortimer <richie@ninjaforge.com>
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_Model
 */
class ComNinjaxplorerModelFiles extends ComNinjaxplorerModelFilesystem
{   
}