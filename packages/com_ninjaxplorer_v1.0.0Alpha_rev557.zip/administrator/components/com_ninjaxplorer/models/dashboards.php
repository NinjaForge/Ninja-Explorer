<?php
/**
 * @version		$Id: dashboards.php 574 2011-03-13 09:36:08Z richie $
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_Model
 * @copyright	Copyright (C) 2007 - 2011 NinjaForge. All rights reserved.
 * @license 	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link     	http://ninjaforge.com
 */
defined('KOOWA') or die("Koowa isn't available, or file is accessed directly"); 

/**
 * Dashboards View Model
 *
 * we are doing some funky stuff in com_ninja so we are extending it, see NinjaAPI docs
 *
 * @author		Richie Mortimer <richie@ninjaforge.com>
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_Model
 */
class ComNinjaxplorerModelDashboards extends ComNinjaModelDashboards {}