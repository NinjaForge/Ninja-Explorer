<?php
/**
 * @version		$Id: filesystem.php 574 2011-03-13 09:36:08Z richie $
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_Model
 * @copyright	Copyright (C) 2007 - 2011 NinjaForge. All rights reserved.
 * @license 	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link     	http://ninjaforge.com
 */
defined('KOOWA') or die("Koowa isn't available, or file is accessed directly"); 

//Autoload the needed classes
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

/**
 * Filesystem Model
 *
 * @author		Richie Mortimer <richie@ninjaforge.com>
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_Model
 */
class ComNinjaxplorerModelFilesystem extends KModelAbstract
{
	/**
	 * Filesystem Path
	 */
	protected $_path;
	
	/**
	 * Constructor
     *
     * @param 	object 	An optional KConfig object with configuration options
	 */
	public function __construct(KConfig $config)
	{
		parent::__construct($config);

		if(!empty($config->path)) {
			$this->setPath($config->path);
		} else {
			$this->_path	= $this->getPath();
		}

		// Set the state
		$this->_state
			->insert('id'       , 'int', 0)
			->insert('path'		, 'string')
			->insert('order'    , 'cmd')
			->insert('direction', 'word', 'asc')
			->insert('search'   , 'string')
			->insert('name'   , 'admin::com.ninja.filter.path');
		
		return $this;
	}
	
	/**
     * Get a list of items which represnts a  table rowset
     *
     * @return KDatabaseRowset
     */
    public function getList()
    {
        // Get the data if it doesn't already exist
        if (!isset($this->_list))
        {
        	$this->_list = $this->_fetchItems();
        }

        return parent::getList();
    }
	
	/**
     * Get the number of items
     */
    public function getTotal()
    {
        // Get the data if it doesn't already exist
        if (!isset($this->_total))
        {
        	$this->_total = count($this->getList());
        }

        return parent::getTotal();
    }
	
	/**
	 * Method to get a table object, load it if necessary.
	 *
	 * @param	array	Options array for view. Optional.
	 * @return	object	The table object
	 */
	public function getPath()
	{
		if(!is_object($this->_path)) {
			if ($path = $this->_state->path) {
				$this->_path	= JPATH_ROOT.DS.$path;
			} else {
				$this->_path	= JPATH_ROOT;
			}
		}

		return $this->_path;
	}
	
	/**
	 * Method to set the path
	 */
	public function setPath($path)
	{
		$this->_path = $path;
		
		return $this;
	}
	
	/**
     * Get the files and folder from the filesystem
     */
    protected function _fetchItems()
    {
		$path = $this->getPath();
		
		$folders 	= array();

		foreach (JFolder::folders($path) as $folder)
		{
			$obj 			= new StdClass;
			$obj->name 		= $folder;
			$obj->path		= str_replace(JPATH_ROOT.DS, '', $path.DS.$folder);
			$obj->parent 	= $path;
			$obj->mime		= 'dir';
			$obj->size		= filesize($folder);
			$folders[]		= $obj;
			
		}

		$files = array();
		foreach (JFolder::files($path) as $file)
		{
			$obj 			= new StdClass;
			$obj->name 		= $file;
			$obj->path		= str_replace(JPATH_ROOT.DS, '', $path.DS.$file);
			$obj->parent 	= $path;
			$obj->mime		= JFile::getExt($file) ? JFile::getExt($file) : 'generic';
			$files[]		= $obj;
		}
		
		$items = array_merge($folders, $files);

		//sort($items);
		
        return $items;
    }
    
    /**
     * Method to get a item object which represents a table row
     *
     * @return Item
     */
    public function getItem()
    {
        // Get the data if it doesn't already exist
        if (!isset($this->_item))
        {
        	if($this->_state->id)
        	{
	        	foreach ($this->_fetchItems() as $item)
	        	{
	        		if($item->name != $this->_state->id) continue;
	       			$template = $item;
	        	}
	        	$this->_item = $template;
	        }
	        else
	        {
	        	$this->_item = current($this->_fetchItems());
	        }
        }

        return parent::getItem();
    }    
}