<?php
/**
 * @version		$Id: filesystem.php 574 2011-03-13 09:36:08Z richie $
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_Template
 * @subpackage	Helpers
 * @copyright	Copyright (C) 2007 - 2011 NinjaForge. All rights reserved.
 * @license 	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link     	http://ninjaforge.com
 */
defined('KOOWA') or die("Koowa isn't available, or file is accessed directly"); 

/**
 * Filesystem Helper Class
 *
 * @author		Richie Mortimer <richie@ninjaforge.com>
 * @category	Ninjaxplorer
 * @package		Ninjaxplorer_Template
 * @subpackage	Helpers
 */
class ComNinjaxplorerTemplateHelperFilesystem extends KTemplateHelperAbstract 
{
	/**
	* Method to get the file size.
	* The FTP layer will be used if its switch on (not all servers support this)
	* else we will do a simple file_size
	*/
	public function fileSize($file)
	{
		jimport('joomla.client.helper');
		$options = JClientHelper::getCredentials('ftp');
		
		if ($options['enabled'] == 1) {
			// Connect the FTP client
			jimport('joomla.client.ftp');
			$ftp = JFTP::getInstance($options['host'], $options['port'], null, $options['user'], $options['pass']);
			
			
			
			
		} else {
			return filesize($file);
		}
	}
}